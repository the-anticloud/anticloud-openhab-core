/*
 * Copyright (c) 2010-2026 Contributors to the openHAB project
 *
 * See the NOTICE file(s) distributed with this work for additional
 * information.
 *
 * This program and the accompanying materials are made available under the
 * terms of the Eclipse Public License 2.0 which is available at
 * http://www.eclipse.org/legal/epl-2.0
 *
 * SPDX-License-Identifier: EPL-2.0
 */
package org.openhab.core.automation.handler;

import org.eclipse.jdt.annotation.NonNullByDefault;
import org.openhab.core.automation.Trigger;

/**
 * This is a base class that can be used by TriggerModuleHandler implementations
 *
 * @author Vasil Ilchev - Initial contribution
 */
@NonNullByDefault
public class BaseTriggerModuleHandler extends BaseModuleHandler<Trigger> implements TriggerHandler {

    public BaseTriggerModuleHandler(Trigger module) {
        super(module);
    }
}
